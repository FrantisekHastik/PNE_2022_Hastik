﻿using System.Text;
using System.Diagnostics;

class Program
{
    public static async Task Main()
    {
        Stopwatch stopwatchS = Stopwatch.StartNew();
        SequentialSolution();
        stopwatchS.Stop();
        Console.WriteLine($"Elapsed time for sequential solution: {stopwatchS.Elapsed}\n\n");

        Stopwatch stopwatchP = Stopwatch.StartNew();
        await ParallelSolution();
        stopwatchP.Stop();
        Console.WriteLine($"Elapsed time for parallel solution: {stopwatchP.Elapsed}\n\n");

        Console.WriteLine($"Comparsion:\nSeq: {stopwatchS.Elapsed}\nPar: {stopwatchP.Elapsed}");
    }

    public static void SequentialSolution()
    {
        try
        {
            Console.WriteLine("Downloading datasets sequentially:");
            var httpClient = new HttpClient();
            var flagsText = httpClient.GetStringAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/flags/flag.data").Result;
            var breastCancerText = httpClient.GetStringAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data").Result;
            var mushroomText = httpClient.GetStringAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/mushroom/agaricus-lepiota.data").Result;
            var zooText = httpClient.GetStringAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/zoo/zoo.data").Result;
            var houseVotesText = httpClient.GetStringAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/voting-records/house-votes-84.data").Result;

            Console.WriteLine("Getting info:");
            Console.WriteLine(GetInfo(flagsText, "Flags"));
            Console.WriteLine(GetInfo(breastCancerText, "Breast cancer"));
            Console.WriteLine(GetInfo(mushroomText, "Mushroom"));
            Console.WriteLine(GetInfo(zooText, "Zoo"));
            Console.WriteLine(GetInfo(houseVotesText, "House votes"));
        }
        catch (Exception ex) { 
            Console.WriteLine(ex.Message);
        }
        
    }

    public static async Task ParallelSolution()
    {

        try
        {
            // In following lines var is Task<string>
            Console.WriteLine("Downloading datasets parallely:");
            var flagResult = DownloadDataAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/flags/flag.data");
            var breastCancerResult = DownloadDataAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data");
            var mushroomResult = DownloadDataAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/mushroom/agaricus-lepiota.data");
            var zooResult = DownloadDataAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/zoo/zoo.data");
            var houseVotesResult = DownloadDataAsync("https://archive.ics.uci.edu/ml/machine-learning-databases/voting-records/house-votes-84.data");

            // If we did not care about the order of printed results, further optimizations could be made
            Console.WriteLine("Getting info:");
            Console.WriteLine(GetInfo(await flagResult, "Flags"));
            Console.WriteLine(GetInfo(await breastCancerResult, "Breast cancer"));
            Console.WriteLine(GetInfo(await mushroomResult, "Mushroom"));
            Console.WriteLine(GetInfo(await zooResult, "Zoo"));
            Console.WriteLine(GetInfo(await houseVotesResult, "House votes"));
        }
        catch (Exception ex) {
            Console.WriteLine(ex.Message);
        }
    }

    public static async Task<string> DownloadDataAsync(string url)
    {
        var httpClient = new HttpClient();
        var text = await httpClient.GetStringAsync(url);
        return text;
    }

    public static string GetInfo(string dataset, string name)
    {
        var byteCount = dataset.Length * sizeof(char);

        string[] items = dataset.Split('\n');           // zde vzniká jeden prázdný řádek navíc, který je třeba odchytit
        string[] splitItem = items[0].Split(',');

        var charCounts = new Dictionary<char, int>();
        int freq = 0;
        foreach (char c in dataset)
        {
            if (!charCounts.ContainsKey(c))
            {
                freq = dataset.Count(f => f == c);
                charCounts.Add(c, freq);
            }
        }

        var result = new StringBuilder();

        result.Append("--------------------------------------------\n");
        result.Append($"Info for dataset {name}:\n");
        result.Append($"Size in kB:       {byteCount / 1000}\n");
        result.Append($"Row amount:       {items.Length - 1}\n");   // zde odchytáváme jeden prázdný řádek navíc
        result.Append($"Column amount:    {splitItem.Length}\n");
        result.Append($"Character amount: {dataset.Length}\n");
        result.Append("Character occurences:\n");
        foreach (KeyValuePair<char, int> kvp in charCounts)
        {
            result.Append($"{kvp.Key} = {kvp.Value}\n");
        }
        result.Append("--------------------------------------------\n");

        return result.ToString();
    }

}